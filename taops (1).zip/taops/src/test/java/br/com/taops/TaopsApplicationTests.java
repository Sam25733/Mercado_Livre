package br.com.taops;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaopsApplicationTests {

	@Test
	void contextLoads() {
	}

}
