'use strict';

(() => {
  const modules = {
    eventos: ['Eventos', 'Organização de ações, datas, responsáveis e instituições participantes.'],
    contatos: ['Candidatos e leads', 'Registro de contatos e acompanhamento da participação nas ações.'],
    parceiros: ['Parceiros', 'Relacionamento com instituições de ensino, empresas e projetos parceiros.'],
    locais: ['Locais e regiões', 'Endereços, orientações de acessibilidade e organização territorial.'],
    logistica: ['Rotas e logística', 'Planejamento de fretados, trajetos e pontos de embarque.'],
    cobertura: ['Mapeamento de cobertura', 'Visão territorial das ações e das regiões atendidas.'],
    comunicacao: ['Comunicação entre áreas', 'Compartilhamento de informações entre equipes autorizadas.'],
    indicadores: ['Indicadores', 'Análise de eventos, contatos, parceiros e cobertura.']
  };
  const menuButton = document.getElementById('menu-toggle');
  const sidebar = document.getElementById('sidebar');
  const backdrop = document.getElementById('backdrop');
  const dashboard = document.getElementById('dashboard-view');
  const moduleView = document.getElementById('module-view');
  const title = document.getElementById('module-title');
  const mobileQuery = window.matchMedia('(max-width: 850px)');

  function setMenu(open, restoreFocus = false) {
    const expanded = open && mobileQuery.matches;
    sidebar.classList.toggle('is-open', expanded);
    document.body.classList.toggle('menu-open', expanded);
    menuButton.setAttribute('aria-expanded', String(expanded));
    menuButton.setAttribute('aria-label', expanded ? 'Fechar navegação' : 'Abrir navegação');
    backdrop.hidden = !expanded;
    if (expanded) sidebar.querySelector('.selected').focus();
    if (restoreFocus) menuButton.focus();
  }

  function showRoute(moveFocus = false) {
    const requested = window.location.hash.slice(1);
    const route = Object.hasOwn(modules, requested) ? requested : 'painel';
    const isDashboard = route === 'painel';
    dashboard.hidden = !isDashboard;
    moduleView.hidden = isDashboard;
    if (!isDashboard) {
      title.textContent = modules[route][0];
      document.getElementById('module-description').textContent = modules[route][1];
    }
    document.title = `${isDashboard ? 'Painel operacional' : modules[route][0]} · TA Ops`;
    sidebar.querySelectorAll('.nav-link').forEach(link => {
      const active = link.getAttribute('href') === `#${route}`;
      link.classList.toggle('selected', active);
      if (active) link.setAttribute('aria-current', 'page');
      else link.removeAttribute('aria-current');
    });
    setMenu(false);
    if (moveFocus) {
      (isDashboard ? document.getElementById('conteudo') : title).focus({ preventScroll: true });
      window.scrollTo({ top: 0, behavior: 'instant' });
    }
  }

  menuButton.addEventListener('click', () => setMenu(menuButton.getAttribute('aria-expanded') !== 'true'));
  backdrop.addEventListener('click', () => setMenu(false, true));
  document.addEventListener('keydown', event => {
    if (menuButton.getAttribute('aria-expanded') !== 'true') return;
    if (event.key === 'Escape') {
      event.preventDefault();
      setMenu(false, true);
    }
    if (event.key === 'Tab') {
      const links = [...sidebar.querySelectorAll('a')];
      const first = links[0];
      const last = links[links.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); menuButton.focus(); }
      else if (event.shiftKey && document.activeElement === menuButton) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); menuButton.focus(); }
      else if (!event.shiftKey && document.activeElement === menuButton) { event.preventDefault(); first.focus(); }
    }
  });
  sidebar.addEventListener('click', event => {
    const link = event.target.closest('a');
    if (link && mobileQuery.matches) {
      setMenu(false);
      if (link.getAttribute('href') === (window.location.hash || '#painel')) {
        document.getElementById('conteudo').focus({ preventScroll: true });
      }
    }
  });
  mobileQuery.addEventListener('change', () => setMenu(false));
  window.addEventListener('hashchange', () => showRoute(true));
  showRoute();
})();
