package br.com.taops;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaopsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaopsApplication.class, args);
	}

}
